import random
print(random.__file__)
# 生成一个 0-10 的数字
rand = random.randint(0,10)

print(rand)